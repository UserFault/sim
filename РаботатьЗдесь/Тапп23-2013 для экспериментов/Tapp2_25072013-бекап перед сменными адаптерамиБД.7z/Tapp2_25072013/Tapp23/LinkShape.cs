﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using Mary;

namespace Tapp23
{
    public class LinkShape
    {
        /// <summary>
        /// LinkSection object
        /// </summary>
        public Mary.MLink m_Link;
        /// <summary>
        /// LinkSection label rect
        /// </summary>
        public System.Drawing.Rectangle m_labelRect;
        /// <summary>
        /// LinkSection label text
        /// </summary>
        public string m_label;
        /// <summary>
        /// LinkSection shape rectangle
        /// </summary>
        public System.Drawing.Rectangle m_linkRect;
        /// <summary>
        /// Point of begin line
        /// </summary>
        public Point m_ptFrom;
        /// <summary>
        /// Point of end line
        /// </summary>
        public Point m_ptTo;
        /// <summary>
        /// LinkSection pen
        /// </summary>
        public Pen m_Pen;

        public LinkShape(MLink li, Point pfrom, Point pto)
        {
            m_ptFrom = pfrom;
            m_ptTo = pto;
            m_Link = li;
            createLinkRect();
            m_Pen = Pens.Black;
        }

        public void Draw(System.Drawing.Graphics g)
        {
            g.DrawLine(m_Pen, m_ptFrom, m_ptTo);

        }

        /// <summary>
        /// Create rect from two points
        /// </summary>
        internal void createLinkRect()
        {
            Point p;
            Size s;
            if (m_ptFrom.X < m_ptTo.X)
            {
                if (m_ptFrom.Y < m_ptTo.Y)
                {
                    p = m_ptFrom;
                    s = new Size(m_ptTo.X - m_ptFrom.X, m_ptTo.Y - m_ptFrom.Y);
                }
                else
                {
                    p = new Point(m_ptFrom.X, m_ptTo.Y);
                    s = new Size(m_ptTo.X - m_ptFrom.X, m_ptFrom.Y - m_ptTo.Y);
                }
            }
            else
            {
                if (m_ptFrom.Y < m_ptTo.Y)
                {
                    p = new Point(m_ptTo.X, m_ptFrom.Y);
                    s = new Size(m_ptFrom.X - m_ptTo.X, m_ptTo.Y - m_ptFrom.Y);

                }
                else
                {
                    p = m_ptTo;
                    s = new Size(m_ptFrom.X - m_ptTo.X, m_ptFrom.Y - m_ptTo.Y);
                }

            }

            if (s.Height == 0) s.Height = 3;
            if (s.Width == 0) s.Width = 3;
            m_linkRect = new System.Drawing.Rectangle(p, s); 
        }
    }
}
