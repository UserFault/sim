﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mary;

namespace Tapp23
{
    /// <summary>
    /// Project file properties form
    /// </summary>
    public partial class ProjSettForm : Form
    {
        private MSolutionInfo m_pfile;

        public ProjSettForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Project settings file
        /// </summary>
        public MSolutionInfo ProjectFile
        {
            get { return m_pfile; }
            set { m_pfile = value; }
        }

        private void ProjSettForm_Load(object sender, EventArgs e)
        {
            this.propertyGrid1.SelectedObject = m_pfile;
        }

        /// <summary>
        /// Reload settings from file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void reloadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            m_pfile = MSolutionInfo.Load(m_pfile.SolutionFilePath);
            propertyGrid1.SelectedObject = m_pfile;
        }
        
        /// <summary>
        /// Save settings file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            m_pfile.Save();
        }

        /// <summary>
        /// Close form without any saving
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }




    }
}
