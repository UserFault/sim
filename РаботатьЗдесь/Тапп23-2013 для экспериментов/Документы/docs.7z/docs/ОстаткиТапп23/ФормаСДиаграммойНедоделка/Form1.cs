﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mary;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace Tapp23
{
    public partial class Form1 : Form
    {
        public Mary.MEngine m_container;
        private MSolutionInfo m_file;
        private Dictionary<int,CellShape> m_cellShapes;
        private List<LinkShape> m_linkShapes;
        private Font m_font;
        private Brush m_normBrush;
        private Brush m_selBrush;
        private Pen m_normPen;
        private Pen m_selPen;

        //drag operation
        private CellShape m_selShape;
        private bool m_dragEnable;
        private bool m_drawShapes;
        
        public Form1()
        {
            InitializeComponent();
            m_cellShapes = new Dictionary<int, CellShape>();
            m_linkShapes = new List<LinkShape>();
            m_font = new Font(FontFamily.GenericMonospace, 10.0F);
            m_normBrush = Brushes.Black;
            m_normPen = Pens.Black;
            m_selBrush = Brushes.Blue; ;
            m_selPen = Pens.Blue;
            m_dragEnable = false;
            m_drawShapes = false; //false prevent drawing container

        }



 





        private void panel_view_Paint(object sender, PaintEventArgs e)
        {
            if (m_drawShapes == false) return; //to prevent shape drawing
            if((m_container == null) || (m_container.Cells.Count == 0)) return;

            e.Graphics.ResetClip();
            int x = 10; int y = 10;

            //add new shapes to collection
            foreach (MCell cell in m_container.Cells.Items)
            {
                if (!m_cellShapes.ContainsKey(cell.CellID.ID))
                {
                    CellShape cs = new CellShape(cell, new Point(x, y));
                    cs.m_Pen = this.m_normPen;
                    cs.m_Brush = this.m_normBrush;
                    m_cellShapes.Add(cell.CellID.ID, cs);
                    y += 10;
                }
            }
            //draw all existing cell shapes, remove non-existing
            foreach (CellShape cs in m_cellShapes.Values)
            {
                if (m_container.Cells.S1_containsCell(cs.m_Cell.CellID))
                    cs.Draw(e.Graphics, m_font);
                else m_cellShapes.Remove(cs.m_Cell.CellID.ID);
            }
            //create and draw cell links
            foreach (CellShape cs in m_cellShapes.Values)
            {
                foreach(MLink lin in cs.m_Cell.Links.Items)
                {
                    LinkShape ls = new LinkShape(lin,m_cellShapes[lin.upCellID.ID].getLinkPoint(), m_cellShapes[lin.downCellID.ID].getLinkPoint() );
                    if (!m_linkShapes.Contains(ls))
                    {
                        m_linkShapes.Add(ls);
                        ls.Draw(e.Graphics);
                    }
                }
            }

        }

        /// <summary>
        /// SolutionOpen project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.toolStripStatusLabel1.Text = "Opening container...";
            //Show dialog to open project file
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Multiselect = false; by default
            ofd.Title = "SolutionOpen project file";
            ofd.DereferenceLinks = true; //use shortcuts for project opening
            ofd.Filter = "Tapp projectfile(.tapj)|*.tapj|All files|*.*";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog(this) != DialogResult.OK) return;
            //else

            //get project file, load settings, create connection string and open container
            //каталог проекта берется из указанного пути к файлу проекта, 
            //поскольку файл проекта должен всегда находиться в каталоге проекта,
            //а этот каталог может свободно перемещаться.

            //open project. All commented checks moved inside
            MEngine me = new MEngine();
            me.SolutionOpen(ofd.FileName);
            this.m_container = me;
            //for-user message 
            this.toolStripStatusLabel1.Text = "Container opened";
            SystemSounds.Beep.Play();
        }





        #region Graphic view  functions

        private void panel_view_MouseMove(object sender, MouseEventArgs e)
        {
            if ((m_selShape != null) && m_dragEnable)
            {
                m_selShape.MoveTo(e.Location);
                Refresh();
            }
        }

        private void panel_view_MouseDown(object sender, MouseEventArgs e)
        {
            CellShape c = this.getShapeFromPoint(e.Location);
            if (c != null)
            {
                //deactivate old shape
                if (m_selShape != null)
                {
                    m_selShape.m_Brush = this.m_normBrush;
                    m_selShape.m_Pen = this.m_normPen;
                }
                    //activate new shape
                m_selShape = c;
                m_selShape.m_Brush = this.m_selBrush;
                m_selShape.m_Pen = this.m_selPen;
                m_dragEnable = true;
                this.Refresh();
            }

        }
        /// <summary>
        /// Return shape contains specified point or null
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        private CellShape getShapeFromPoint(Point point)
        {
            foreach (CellShape cs in m_cellShapes.Values)
            {
                if (cs.m_cellRect.Contains(point)) return cs;
            }
            return null;
        }

        private void panel_view_MouseUp(object sender, MouseEventArgs e)
        {
            m_dragEnable = false;
        }

        #endregion







        

    }
}
