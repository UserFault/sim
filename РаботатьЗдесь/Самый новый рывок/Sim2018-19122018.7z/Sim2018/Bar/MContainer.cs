﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Bar.Container;

namespace Bar
{
    /// <summary>
    /// NR-Представляет контейнер Солюшена
    /// </summary>
    /// <remarks>
    /// Значения для интерфейса MObject берутся из объекта MSolutionSettings.
    /// </remarks>
    public class MContainer: MElement
    {

        #region *** Fields ***
        /// <summary>
        /// Обратная ссылка на Солюшен
        /// </summary>
        private MSolution m_Solution;

        /// <summary>
        /// Адаптер БД - кэш ссылки из MSolution, если он потребуется. Но лучше пользоваться им из MSolution
        /// </summary>
        private Bar.DatabaseAdapters.BaseDbAdapter m_DbAdapter;
        
        /// <summary>
        /// Коллекция ячеек контейнера
        /// </summary>
        private MCellCollection m_Cells;

        /// <summary>
        /// Коллекция связей контейнера
        /// </summary>
        private MContainerLinkCollection m_Links;
        
        #endregion

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="solutionRef">Ссылка на объект Солюшена</param>
        public MContainer(MSolution solutionRef)
        {
            m_Solution = solutionRef;
            //TODO: Add code here...
        }

        #region *** Properties ***
        /// <summary>
        /// Коллекция ячеек контейнера
        /// </summary>
        public MCellCollection Cells
        {
            get { return m_Cells; }
        }

        /// <summary>
        /// Коллекция связей контейнера
        /// </summary>
        public MContainerLinkCollection Links
        {
            get { return m_Links; }
        }

        /// <summary>
        /// Адаптер БД
        /// </summary>
        public Bar.DatabaseAdapters.BaseDbAdapter DbAdapter
        {
            get { return m_DbAdapter; }
        }
#endregion

        #region *** MElement property set ***
        //Значения для интерфейса MElement берутся из объекта MSolutionSettings
        
        /// <summary>
        /// Идентификатор элемента
        /// </summary>
        public override MID ID
        {
            get
            {   
                return new MID(this.m_Solution.Settings.SolutionId, 0);//TODO: MID-invalid identifier value?
            }
            set
            {
                this.m_Solution.Settings.SolutionId = value.ContainerId;
            }
        }
        
        
        /// <summary>
        /// Название элемента
        /// </summary>
        public override string Name
        {
            get { return this.m_Solution.Settings.SolutionName; }
            set { this.m_Solution.Settings.SolutionName = value; }
        }
        
        /// <summary>
        /// текстовое описание, String.Empty по умолчанию.
        /// </summary>
        public override string Description
        {
            get { return this.m_Solution.Settings.SolutionDescription; }
            set { this.m_Solution.Settings.SolutionDescription = value; }
        }

        /// <summary>
        /// Flag is element active or deleted 
        /// Default true
        /// </summary>
        public override bool isActive
        {
            get { return this.m_Solution.Settings.ContainerIsActiveFlag; }
            set { this.m_Solution.Settings.ContainerIsActiveFlag = value; }
        }

        /// <summary>
        /// Поле для значения, используемого в сервисных операциях (поиск в графе,  обслуживание и так далее) //default 0
        /// </summary>
        public override int ServiceFlag
        {
            get { return this.m_Solution.Settings.ContainerServiceFlag; }
            set { this.m_Solution.Settings.ContainerServiceFlag = value; }
        }

        /// <summary>
        /// Состояние элемента 
        /// </summary>
        /// <remarks>default 0</remarks>
        public override MID State
        {
            get { return MID.FromU64(this.m_Solution.Settings.ContainerState); }
            set { this.m_Solution.Settings.ContainerState = value.ToU64(); }
        }
        #endregion

        /// <summary>
        /// NR-Открыть менеджер
        /// </summary>
        /// <param name="settings"></param>
        public void Open(MSolutionSettings settings)
        {
            //TODO: Add code here...
        }

        /// <summary>
        /// NR-Закрыть менеджер
        /// </summary>
        public void Close()
        {
            //TODO: Add code here...
        }



       #region *** MObject serialization functions ***
        /// <summary>
        /// Convert object data to binary stream
        /// </summary>
        /// <param name="writer">Binary stream writer</param>
        public override void toBinary(BinaryWriter writer)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from binary stream
        /// </summary>
        /// <param name="reader">Binary stream reader</param>
        public override void fromBinary(BinaryReader reader)
        {
            throw new NotImplementedException();
        }
        ///// <summary>
        ///// Convert object data to byte array
        ///// </summary>
        ///// <returns></returns>
        //public override byte[] toBinaryArray()
        //{
        //    //create memory stream and writer
        //    MemoryStream ms = new MemoryStream(64);//initial size for cell data 
        //    BinaryWriter bw = new BinaryWriter(ms, Encoding.Unicode);
        //    //convert data
        //    this.toBinary(bw);
        //    //close memory stream and get bytes
        //    bw.Close();
        //    return ms.ToArray();
        //}
        /// <summary>
        /// Convert object data to text string
        /// </summary>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        /// <returns></returns>
        public override string toTextString(bool withHex)
        {
            throw new NotImplementedException();//TODO: Добавить обобщенный наследуемый код сериализации здесь
        }
        /// <summary>
        /// Convert object data to text stream
        /// </summary>
        /// <param name="writer">text stream writer</param>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        public override void toText(TextWriter writer, bool withHex)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from text stream
        /// </summary>
        /// <param name="reader">text stream reader</param>
        public override void fromText(TextReader reader)
        {
            throw new NotImplementedException();
        }
        #endregion

    }
}
