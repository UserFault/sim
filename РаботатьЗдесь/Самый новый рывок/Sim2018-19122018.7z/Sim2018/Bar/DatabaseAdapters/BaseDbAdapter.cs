﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar.DatabaseAdapters
{
    /// <summary>
    /// NR-Базовый класс адаптера БД
    /// </summary>
    [MDatabaseTypeAttribute(MDatabaseType.Unknown, false)] //атрибут для автоматической проверки доступных типов БД Солюшена
    public class BaseDbAdapter
    {
        //Аргумент true означает, что данный класс закончен и может быть использован для работы с соответствующей БД.
        //Аргумент false означает, что класс будет игнорироваться.
        //Атрибут из этого класса можно убрать, он тут только для шаблона. 
        //Он должен быть в производных классах адаптеров БД, а не здесь.
        //Если его оставить тут активным, в релизе будет светиться тип БД: Unknown. 
        //А это неправильно.
        
        
        //TODO: Через технологию отражения проверять доступность указанного типа БД для Солюшена при его открытии.
        //Сейчас этот код находится в MUtility классе, и его надо еще доводить до рабочего состояния.    
        
        //все интерфейсные функции этого класса нужно объявить абстрактными или перегруженными или виртуальными. 
        //их реализация предполагается в классах-потомках. Но это надо разбираться комплексно со всеми функциями сразу.
        
        #region *** Fields ***
        /// <summary>
        /// Обратная ссылка на Солюшен
        /// </summary>
        private MSolution m_Solution;

        #endregion

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="solutionRef">Ссылка на объект Солюшена</param>
        public BaseDbAdapter(MSolution solutionRef)
        {
            m_Solution = solutionRef;
            //TODO: Add code here...
        }

        #region *** Properties ***
        #endregion

        /// <summary>
        /// NR-Открыть менеджер
        /// </summary>
        /// <param name="settings"></param>
        public void Open(MSolutionSettings settings)
        {
            //TODO: Add code here...
        }

        /// <summary>
        /// NR-Закрыть менеджер
        /// </summary>
        public void Close()
        {
            //TODO: Add code here...
        }




        /// <summary>
        /// NR-Получить из БД макс ИД связей текущего солюшена
        /// </summary>
        /// <returns>Возвращает максимальный ИД связей текущего солюшена или 0 если нет таких связей</returns>
        internal int getMaxLinkId()
        {
            //Взять идентификатор текущего солюшена из объекта солюшена в адаптере
            throw new NotImplementedException();//TODO: Add code here...
        }


        /// <summary>
        /// NR-Получить из БД макс ИД ячеек текущего солюшена
        /// </summary>
        /// <returns>Возвращает максимальный ИД ячеек текущего солюшена или 0 если нет таких ячеек</returns>
        internal int getMaxCellId()
        {
            //Взять идентификатор текущего солюшена из объекта солюшена в адаптере
            throw new NotImplementedException();//TODO: Add code here...
        }



    }
}
