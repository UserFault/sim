﻿using System;
using System.IO;
using Bar.Container;

namespace Bar
{
    /// <summary>
    /// RT-Обеспечивает единообразие полей для Связей, Ячеек и Контейнера
    /// </summary>
    public abstract class MElement: MObject
    {
        #region *** MElement property set ***
        /// <summary>
        /// Идентификатор элемента
        /// </summary>
        public abstract MID ID
        {
            get;
            set;
        }

        /// <summary>
        /// Название элемента
        /// </summary>
        public abstract string Name
        {
            get;
            set;
        }
        
        /// <summary>
        /// текстовое описание, String.Empty по умолчанию.
        /// </summary>
        public abstract string Description
        {
            get;
            set;
        }

        /// <summary>
        /// Flag is element active or deleted 
        /// Default true
        /// </summary>
        public abstract bool isActive
        {
            get;
            set;
        }

        /// <summary>
        /// Поле для значения, используемого в сервисных операциях (поиск в графе,  обслуживание и так далее) //default 0
        /// </summary>
        public abstract int ServiceFlag
        {
            get;
            set;
        }

        /// <summary>
        /// Вынесен из подклассов как общее свойство. Link state id. //default 0
        /// </summary>
        public abstract MID State
        {
            get;
            set;
        }
        #endregion

        #region *** MObject serialization functions ***
        /// <summary>
        /// Convert object data to binary stream
        /// </summary>
        /// <param name="writer">Binary stream writer</param>
        public override void toBinary(BinaryWriter writer)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from binary stream
        /// </summary>
        /// <param name="reader">Binary stream reader</param>
        public override void fromBinary(BinaryReader reader)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data to byte array
        /// </summary>
        /// <returns></returns>
        public override byte[] toBinaryArray()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data to text string
        /// </summary>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        /// <returns></returns>
        public override string toTextString(bool withHex)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data to text stream
        /// </summary>
        /// <param name="writer">text stream writer</param>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        public override void toText(TextWriter writer, bool withHex)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from text stream
        /// </summary>
        /// <param name="reader">text stream reader</param>
        public override void fromText(TextReader reader)
        {
            throw new NotImplementedException();
        }
        #endregion

    }
}
