﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar
{
    
    /// <summary>
    /// NR-Представляет Солюшен и собственно Движок для клиентов Движка
    /// </summary>
    public class MSolution
    {

        ///// <summary>
        ///// Статический объект класса без инициализации.
        ///// Приведен здесь для удобства - чтобы хоть где-то был упомянут.
        ///// </summary>
        ////Напоминание: MSolutionRefCollection.AddSolutionReference(..);//TODO: отправить сюда ссылку на солюшен при его создании или открытии.

        #region Fields

        /// <summary>
        /// Менеджер контейнера
        /// </summary>
        private MContainer m_Container;


        /// <summary>
        /// Менеджер подсистемы ресурсов
        /// </summary>
        private MResourceManager m_ResourceManager;


        /// <summary>
        /// Менеджер подсистемы методов
        /// </summary>
        private MMethodManager m_MethodManager;


        /// <summary>
        /// Менеджер подсистемы снимков
        /// </summary>
        private MSnapshotManager m_SnapshotManager;


        /// <summary>
        /// Менеджер подсистемы лога
        /// </summary>
        private MLogManager m_LogManager;


        /// <summary>
        /// Настройки  Солюшена и константы Движка
        /// </summary>
        private MSolutionSettings m_Settings;


        /// <summary>
        /// Менеджер подсистемы БД
        /// </summary>
        private Bar.DatabaseAdapters.BaseDbAdapter m_DbAdapter;

        #endregion

        /// <summary>
        /// Конструктор
        /// </summary>
        public MSolution()
        {
            throw new System.NotImplementedException();//TODO: Add code here...
        }

        /// <summary>
        /// Деструктор
        /// </summary>
        ~MSolution()
        {
            throw new System.NotImplementedException();//TODO: Add code here...
        }

        #region Properties
        /// <summary>
        /// Менеджер контейнера
        /// </summary>
        public MContainer Container
        {
            get { return m_Container; }
            set { m_Container = value; }
        }
        /// <summary>
        /// Менеджер подсистемы ресурсов
        /// </summary>
        public MResourceManager Resources
        {
            get { return m_ResourceManager; }
            set { m_ResourceManager = value; }
        }
        /// <summary>
        /// Менеджер подсистемы методов
        /// </summary>
        public MMethodManager Methods
        {
            get { return m_MethodManager; }
            set { m_MethodManager = value; }
        }
        /// <summary>
        /// Менеджер подсистемы снимков
        /// </summary>
        public MSnapshotManager Snapshots
        {
            get { return m_SnapshotManager; }
            set { m_SnapshotManager = value; }
        }
        /// <summary>
        /// Менеджер подсистемы лога
        /// </summary>
        public MLogManager Logs
        {
            get { return m_LogManager; }
            set { m_LogManager = value; }
        }
        /// <summary>
        /// Настройки  Солюшена и константы Движка
        /// </summary>
        public MSolutionSettings Settings
        {
            get { return m_Settings; }
            set { m_Settings = value; }
        }
        /// <summary>
        /// Менеджер подсистемы БД
        /// </summary>
        public Bar.DatabaseAdapters.BaseDbAdapter DbAdapter
        {
            get { return m_DbAdapter; }
            set { m_DbAdapter = value; }
        }
        /// <summary>
        /// Кеш идентификатора солюшена 
        /// </summary>
        public int Id
        {
            get { return this.m_Settings.SolutionId; }
        }

        #endregion


        public override string ToString()
        {
            return base.ToString();//TODO: Add ToString code here...
        }
    }
}
