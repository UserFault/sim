﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Bar.Container
{
    public class MLink : MElement
    {

        #region *** MElement property set ***
        /// <summary>
        /// Идентификатор элемента
        /// </summary>
        public override MID ID
        {
            get
            {
                throw new NotImplementedException();//TODO: Add code here...
            }
            set
            {
                throw new NotImplementedException();//TODO: Add code here...
            }
        }
        
        /// <summary>
        /// Название элемента
        /// </summary>
        /// <remarks>Для связи не хранится название. Проперти всегда возвращает пустую строку.</remarks>
        public override string Name
        {
            get { return String.Empty; }
            set {  }
        }

        /// <summary>
        /// текстовое описание, String.Empty по умолчанию.
        /// </summary>
        public override string Description
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Flag is element active or deleted 
        /// Default true
        /// </summary>
        public override bool isActive
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Поле для значения, используемого в сервисных операциях (поиск в графе,  обслуживание и так далее) //default 0
        /// </summary>
        public override int ServiceFlag
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Link state id. //default 0
        /// </summary>
        public override MID State
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }
        #endregion

       #region *** MObject serialization functions ***
        /// <summary>
        /// Convert object data to binary stream
        /// </summary>
        /// <param name="writer">Binary stream writer</param>
        public override void toBinary(BinaryWriter writer)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from binary stream
        /// </summary>
        /// <param name="reader">Binary stream reader</param>
        public override void fromBinary(BinaryReader reader)
        {
            throw new NotImplementedException();
        }
        ///// <summary>
        ///// Convert object data to byte array
        ///// </summary>
        ///// <returns></returns>
        //public override byte[] toBinaryArray()
        //{
        //    //create memory stream and writer
        //    MemoryStream ms = new MemoryStream(64);//initial size for cell data 
        //    BinaryWriter bw = new BinaryWriter(ms, Encoding.Unicode);
        //    //convert data
        //    this.toBinary(bw);
        //    //close memory stream and get bytes
        //    bw.Close();
        //    return ms.ToArray();
        //}
        /// <summary>
        /// Convert object data to text string
        /// </summary>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        /// <returns></returns>
        public override string toTextString(bool withHex)
        {
            throw new NotImplementedException();//TODO: Добавить обобщенный наследуемый код сериализации здесь
        }
        /// <summary>
        /// Convert object data to text stream
        /// </summary>
        /// <param name="writer">text stream writer</param>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        public override void toText(TextWriter writer, bool withHex)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from text stream
        /// </summary>
        /// <param name="reader">text stream reader</param>
        public override void fromText(TextReader reader)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
