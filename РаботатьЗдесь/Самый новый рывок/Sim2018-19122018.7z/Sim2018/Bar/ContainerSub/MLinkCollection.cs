﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar.Container
{
    public class MLinkCollection
    {
        public MLinkCollection()
        {
            throw new System.NotImplementedException();
        }
    }
}
