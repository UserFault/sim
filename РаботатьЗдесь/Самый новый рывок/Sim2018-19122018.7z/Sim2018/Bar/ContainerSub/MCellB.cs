﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Bar.Container
{
    /// <summary>
    /// NR-Представляет ячейку Солюшена в разных видах поведения
    /// </summary>
    public class MCellB : MCell
    {
#region *** Fields ***
        /// <summary>
        /// Режим ячейки
        /// </summary>
        private MCellMode m_cellMode;

#endregion

        //TODO: добавить конструктор и поля класса MCellB

        #region *** MElement property set ***
        /// <summary>
        /// Идентификатор элемента
        /// </summary>
        public override MID ID
        {
            get
            {
                throw new NotImplementedException();//TODO: Add code here...
            }
            set
            {
                throw new NotImplementedException();//TODO: Add code here...
            }
        }

        /// <summary>
        /// Название элемента
        /// </summary>
        public override string Name
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// текстовое описание, String.Empty по умолчанию.
        /// </summary>
        public override string Description
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Flag is element active or deleted 
        /// Default true
        /// </summary>
        public override bool isActive
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Поле для значения, используемого в сервисных операциях (поиск в графе,  обслуживание и так далее) //default 0
        /// </summary>
        public override int ServiceFlag
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Вынесен из подклассов как общее свойство. Link state id. //default 0
        /// </summary>
        public override MID State
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }
        #endregion

        #region *** MCell Property set ***

        /// <summary>
        /// Cell type id
        /// </summary>
        public override MID TypeId
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Cell creation timestamp
        /// </summary>
        public override DateTime CreaTime
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            internal set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Last modification timestamp
        /// </summary>
        public override DateTime ModiTime
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            internal set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Cell is read-only flag (not used currently)
        /// </summary>
        public override bool ReadOnly
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Cell data value
        /// </summary>
        public override byte[] Value
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Cell data value type id
        /// </summary>
        public override MID ValueTypeId
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
            set { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Cell link collection. 
        /// Only for link reading!
        /// </summary>
        public override MLinkCollection Links
        {
            get { throw new NotImplementedException(); }//TODO: Add code here...
        }

        /// <summary>
        /// Cell (saving) mode: Compact, Normal, DelaySave, Temporary
        /// </summary>
        public override MCellMode CellMode
        {
            get
            {
                return m_cellMode;  
            }
            internal set
            {
                if (value == MCellMode.Compact) throw new Exception("Try to set Compact cell mode for MCellB cell");
                //Check Temporary state restriction
                if (((m_cellMode == MCellMode.Temporary) && (value != MCellMode.Temporary)) 
                    || ((value == MCellMode.Temporary) && (m_cellMode != MCellMode.Temporary)))
                {
                    throw new Exception("Cell save mode change fail");
                }
                else
                    m_cellMode = value;
            }
        }

        /// <summary>
        /// Current cell is MCellB cell? 
        /// (This property is read only)
        /// </summary>
        public override bool isLargeCell
        {
            get { return true; }
        }

        #endregion


       #region *** MObject serialization functions ***
        /// <summary>
        /// Convert object data to binary stream
        /// </summary>
        /// <param name="writer">Binary stream writer</param>
        public override void toBinary(BinaryWriter writer)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }
        /// <summary>
        /// Convert object data from binary stream
        /// </summary>
        /// <param name="reader">Binary stream reader</param>
        public override void fromBinary(BinaryReader reader)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }
        /// <summary>
        /// Convert object data to byte array
        /// </summary>
        /// <returns></returns>
        public override byte[] toBinaryArray()
        {
            throw new NotImplementedException();//TODO: Add code here...
        }
        /// <summary>
        /// Convert object data to text string
        /// </summary>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        /// <returns></returns>
        public override string toTextString(bool withHex)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }
        /// <summary>
        /// Convert object data to text stream
        /// </summary>
        /// <param name="writer">text stream writer</param>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        public override void toText(TextWriter writer, bool withHex)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }
        /// <summary>
        /// Convert object data from text stream
        /// </summary>
        /// <param name="reader">text stream reader</param>
        public override void fromText(TextReader reader)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }
        #endregion
    }
}
