﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar.Container
{
    /// <summary>
    /// Cell work mode: Compact, Normal, DelaySave or Temporary.
    /// </summary>
    /// <remarks>Значения элементов используются при выборе приоритетной ячейки при создании связи.</remarks>
    public enum MCellMode
    {
        /// <summary>
        /// MCellA cell type. Минимум памяти, все данные хранятся в БД
        /// </summary>
        Compact = 0,
        /// <summary>
        /// MCellB cell type. Значения кешируются для быстрого чтения, все изменения немедленно записываются в БД.
        /// </summary>
        Normal = 1,
        /// <summary>
        /// MCellBds cell type. Запись изменений откладывается до вызова Save(). Ячейка автоматически сохраняется при создании и при выгрузке из памяти.
        /// </summary>
        DelaySave = 2,
        /// <summary>
        /// MCellBt cell type. Временная ячейка. Запись ячейки в таблицу производится только вызовом Save(), после которого ячейка переходит в состояние Normal. 
        /// При создании ячейка не записывается в таблицу.
        /// </summary>
        Temporary = 3,
    }
}
