﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar.Container
{
    /// <summary>
    /// NR-Базовый класс Идентификатора связи или ячейки
    /// </summary>
    public class MID
    {

        #region *** Fields ***
        /// <summary>
        /// Element identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private int m_elementid;
        /// <summary>
        /// Container identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        private int m_containerid;
        #endregion
        
        public MID()
        {
            m_elementid = 0;
            m_containerid = 0;
        }

        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="containerId">Container ID number</param>
        /// <param name="elementId">Element ID number</param>
        public MID(int containerId, int elementId)
        {
            m_containerid = containerId;
            m_elementid = elementId;
        }

        /// <summary>
        /// Конструктор копии
        /// </summary>
        /// <param name="copy">Source object</param>
        public MID(MID copy)
        {
            m_elementid = copy.m_elementid;
            m_containerid = copy.m_containerid;
        }

        #region *** Properties ***
        /// <summary>
        /// Container identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public int ContainerId
        {
            get { return m_containerid; }
            set { m_containerid = value; }
        }
        /// <summary>
        /// Element identifier number
        /// </summary>
        /// <remarks></remarks>
        /// <value></value>
        /// <seealso cref=""/>
        public int ElementId
        {
            get { return m_elementid; }
            set { m_elementid = value; }
        }
        

        //если надо определять ИД ячейки или связи, то можно сделать в классах override проперти IsLinkID IsCellID
        //и в них возвращать true false. Чтобы не тратить память на хранение флага и не проверять типы объектов в коде.
        
        /// <summary>
        /// Флаг, что объект - Идентификатор связи
        /// </summary>
        /// <remarks>Значение флага не хранится в памяти</remarks>
        public virtual bool IsLinkID
        {
            get { return false; }
        }
        /// <summary>
        /// Флаг, что объект - Идентификатор ячейки
        /// </summary>
        /// <remarks>Значение флага не хранится в памяти</remarks>
        public virtual bool IsCellID
        {
            get { return false; }
        }
        #endregion

        /// <summary>
        /// NT-Check that current Id is Temporary
        /// </summary>
        /// <returns>Returns True if Id is temporary, False otherwise</returns>
        public bool isTemporaryId()
        {
            return (m_elementid < 0);
        }

        /// <summary>
        /// NT-Check that specified element identifier is Temporary
        /// </summary>
        /// <param name="elementid">element id value</param>
        /// <returns>Returns True if specified element id is Temporary element, False otherwise.</returns>
        public static bool isTemporaryId(int elementid)
        {
            return (elementid < 0);
        }

        internal static int getNewTempId(int t)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }

        internal static int getNewConstId(int t)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }

        internal static MID CreateLocalID(int t)
        {
            throw new NotImplementedException();//TODO: Add code here...
            
        }


        /// <summary>
        /// NT-Unpack element identifier from U64 value
        /// </summary>
        /// <param name="id">Packed to U64 identifier</param>
        /// <returns>Returns unpacked element identifier.</returns>
        public static MID FromU64(UInt64 id)
        {
            Int32 elementid = (Int32)(id & 0xFFFFFFFF);
            Int32 containerid = (Int32)(id >> 32);
            return new MID(containerid, elementid);
        }
        /// <summary>
        /// NT-Pack element identifier to U64 value
        /// </summary>
        /// <returns>Returns packed element identifier as U64 value.</returns>
        public UInt64 ToU64()
        {
            UInt64 res = 0;
            res = res | ((UInt64)((UInt32)this.m_containerid));
            res = res << 32;
            res = res | ((UInt64)((UInt32)this.m_elementid));
            return res;
        }

        /// <summary>
        /// NT-Get string representation of object
        /// </summary>
        /// <returns>Returns string representation of object, like 0:0</returns>
        public override string ToString()
        {
            return String.Format("{0}:{1}", m_containerid, m_elementid);
        }



        //натасканы старые функции - их надо переделать и приспособить если они нужны
        
        ///// <summary>
        ///// NT-Создает локальный идентификатор - для текущего контейнера
        ///// </summary>
        ///// <param name="elementId">Идентификатор элемента</param>
        ///// <returns>Возвращает локальный идентификатор.</returns>
        ///// <remarks></remarks>
        ///// <seealso cref=""/>
        //public static MID CreateLocalID(int elementId)
        //{
        //    return new MID(MEngine.CurrentContainer.ContainerIdNumber, elementId);
        //}
        ///// <summary>
        ///// NT-Проверяет, что идентификатор локальнй, то есть принадлежит текущему контейнеру.
        ///// Использование внутри цикла ухудшает производительность.
        ///// </summary>
        ///// <returns>Returns True if Id is local, False otherwise</returns>
        ///// <remarks></remarks>
        ///// <remarks></remarks>
        ///// <seealso cref=""/>
        //public bool IsLocalId()
        //{
        //    return (m_containerid == MEngine.CurrentContainer.ContainerIdNumber);
        //}





        ///// <summary>
        ///// Check ordinal Id value and throw exception
        ///// </summary>
        //public void checkId()
        //{
        //    if (m_elementid == 0)
        //        throw new Exception("Invalid element identifier");
        //    else if((m_elementid == Int32.MaxValue) || (m_elementid == Int32.MinValue))
        //        throw new Exception("Too big cell identifier");
        //}

        ///// <summary>
        ///// Get new element id for new constant element
        ///// </summary>
        ///// <param name="maxId">max of existing constant element id</param>
        ///// <returns>Returns new element id for new constant element</returns>
        //public static int getNewConstId(int maxId)
        //{
        //    return maxId + 1;
        //}

        ///// <summary>
        ///// Get new element id for new temporary element
        ///// </summary>
        ///// <param name="maxId">max of existing temporary element id</param>
        ///// <returns>Returns new element id for new temporary element</returns>
        //public static int getNewTempId(int maxId)
        //{
        //    return maxId - 1;
        //}

        ///// <summary>
        ///// Return true if identifiers is equal
        ///// </summary>
        ///// <param name="tid">Compared identifier</param>
        ///// <returns>Returns True if identifiers is equals, False otherwise</returns>
        //public bool isEqual(MID tid)
        //{
        //    return ((tid.m_elementid == this.m_elementid) && (tid.m_containerid == this.m_containerid));
        //} 



    }
    /// <summary>
    /// NR-Класс Идентификатора ячейки
    /// </summary>
    public class MCellId : MID
    {
        public MCellId()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Флаг, что объект - Идентификатор связи
        /// </summary>
        /// <remarks>Значение флага не хранится в памяти</remarks>
        public override bool IsLinkID
        {
            get { return false; }
        }
        /// <summary>
        /// Флаг, что объект - Идентификатор ячейки
        /// </summary>
        /// <remarks>Значение флага не хранится в памяти</remarks>
        public override bool IsCellID
        {
            get { return true; }
        }
    }
    /// <summary>
    /// NR-Класс Идентификатора связи 
    /// </summary>
    public class MLinkId : MID
    {
        public MLinkId()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Флаг, что объект - Идентификатор связи
        /// </summary>
        /// <remarks>Значение флага не хранится в памяти</remarks>
        public override bool IsLinkID
        {
            get { return true; }
        }
        /// <summary>
        /// Флаг, что объект - Идентификатор ячейки
        /// </summary>
        /// <remarks>Значение флага не хранится в памяти</remarks>
        public override bool IsCellID
        {
            get { return false; }
        }
    }
}
