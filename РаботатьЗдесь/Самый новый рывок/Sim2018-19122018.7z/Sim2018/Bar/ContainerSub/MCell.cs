﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Bar.Container
{
    public abstract class MCell: MElement
    {
        /// <summary>
        /// Порог числа связей ячейки при выборе: поиск в памяти или в таблице.
        /// </summary>
        /// <remarks>Зависит от производительности сервера БД, сети и состония БД. Подобрать значение опытным путем в процессе тестов.</remarks>
        public static int LinksTreshold = 512;

        //конструктора нет.

        #region *** Properties ***

        //Дополнительные абстрактные проперти впридачу к MElement, для производных классов.

        /// <summary>
        /// Cell type id
        /// </summary>
        public abstract MID TypeId
        {
            get;
            set;
        }

        /// <summary>
        /// Cell creation timestamp
        /// </summary>
        public abstract DateTime CreaTime
        {
            get;
            internal set;
        }

        /// <summary>
        /// Last modification timestamp
        /// </summary>
        public abstract DateTime ModiTime
        {
            get;
            internal set;
        }

        /// <summary>
        /// Cell is read-only flag (not used currently)
        /// </summary>
        public abstract bool ReadOnly
        {
            get;
            set;
        }

        /// <summary>
        /// Cell data value
        /// </summary>
        public abstract byte[] Value
        {
            get;
            set;
        }

        /// <summary>
        /// Cell data value type id
        /// </summary>
        public abstract MID ValueTypeId
        {
            get;
            set;
        }

        /// <summary>
        /// Cell link collection. 
        /// Only for link reading!
        /// </summary>
        public abstract MLinkCollection Links
        {
            get;
        }

        /// <summary>
        /// Cell (saving) mode: Compact, Normal, DelaySave, Temporary
        /// </summary>
        public abstract MCellMode CellMode
        {
            get;
            internal set;
        }

        /// <summary>
        /// Current cell is MCellB cell? 
        /// (This property is read only)
        /// </summary>
        public abstract bool isLargeCell
        {
            get;
        }
#endregion

        //*** MElement property set *** - так как класс абстрактный, тут переопределять их не надо. Поэтому они удалены.
        





       #region *** MObject serialization functions ***
        // осмотрены для первой компиляции проекта 
        /// <summary>
        /// Convert object data to binary stream
        /// </summary>
        /// <param name="writer">Binary stream writer</param>
        public override void toBinary(BinaryWriter writer)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from binary stream
        /// </summary>
        /// <param name="reader">Binary stream reader</param>
        public override void fromBinary(BinaryReader reader)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data to byte array
        /// </summary>
        /// <returns></returns>
        public override byte[] toBinaryArray()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data to text string
        /// </summary>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        /// <returns></returns>
        public override string toTextString(bool withHex)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data to text stream
        /// </summary>
        /// <param name="writer">text stream writer</param>
        /// <param name="withHex">True - include HEX representation of binary data</param>
        public override void toText(TextWriter writer, bool withHex)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Convert object data from text stream
        /// </summary>
        /// <param name="reader">text stream reader</param>
        public override void fromText(TextReader reader)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
