﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar.Container
{
    /// <summary>
    /// NR-Представляет коллекцию ячеек в контейнере Солюшена
    /// </summary>
    public class MCellCollection
    {
        #region *** Fields ***
        /// <summary>
        /// Обратная ссылка на Солюшен
        /// </summary>
        private MSolution m_Solution;

        #endregion

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="solutionRef">Ссылка на объект Солюшена</param>
        public MCellCollection(MSolution solutionRef)
        {
            m_Solution = solutionRef;
            //TODO: Add code here...
        }

        #region *** Properties ***
        #endregion

        ///// <summary>
        ///// NR-Открыть менеджер
        ///// </summary>
        ///// <param name="settings"></param>
        //public void Open(MSolutionSettings settings)
        //{
        //    //TODO: Add code here...
        //}

        ///// <summary>
        ///// NR-Закрыть менеджер
        ///// </summary>
        //public void Close()
        //{
        //    //TODO: Add code here...
        //}
        
        
        
        /// <summary>
        /// NR-Получить из коллекции ячеек контейнера макс ИД временных ячеек текущего контейнера
        /// </summary>
        /// <returns>Возвращает максимальный ИД временных ячеек текущего солюшена или 0 если нет таких ячеек</returns>
        internal int getMaxTempCellID()
        {
            //взять ид солюшена из объекта контейнера здесь
            //выбрать ячейки по ид текущего солюшена и с отрицательным ИД,
            //потом определить максимум (по модулю) из этих ид (все ид отрицательные, поэтому минимум)
            //вернуть 0 если таких ячеек нет, иначе вернуть найденный ИД.
            throw new NotImplementedException();//TODO: Add code here...
        }
    }
}
