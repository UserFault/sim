﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bar
{
    /// <summary>
    /// Коллекция ссылок на объекты разных Солюшенов
    /// </summary>
    /// <remarks>
    /// Этот класс проектируется впервые и может содержать непроверенные решения.
    /// Это полностью статический класс, который создается при создании солюшена.
    /// Он либо изолирует, либо объединяет ссылки на солюшены, открытые в процессе движка.
    /// И размечает доступ к контейнеру для ячейки или связи в мультиконтейнерной или сетевой конфигурации движка.
    /// </remarks>
    public static class MSolutionRefCollection
    {
        private static Dictionary<int, MSolution> dictionary;

        /// <summary>
        /// NT-Добавить ссылку на объект Солюшена в коллекцию
        /// </summary>
        /// <param name="solutionRef">Ссылка на объект Солюшена</param>
        public static void AddSolutionReference(MSolution solutionRef)
        {
            //create new dictionary if not exists
            if (dictionary == null)
                dictionary = new Dictionary<int, MSolution>();
            //add ref to dictionary if not exists
            int key = solutionRef.Id;
            if (dictionary.ContainsKey(key))
            {
                //проверить что это тот же объект солюшена, с тем же адресом в памяти.
                //если нет - выдать исключение
                MSolution sol = dictionary[key];
                if (sol != solutionRef) //TODO: тут сравнить адреса объектов в памяти
                    throw new ApplicationException("Другой объект Солюшена с тем же ИД уже существует");
            }
            else
            {
                dictionary.Add(key, solutionRef);
            }

            return;
        }
        /// <summary>
        /// NT-Получить ссылку на объект Солюшена по его идентификатору
        /// </summary>
        /// <param name="id">Идентификатор Солюшена</param>
        /// <returns>Возвращает ссылку на объект Солюшена или выбрасывает исключение, если объект не найден в коллекции.</returns>
        public static MSolution GetSolutionReference(int id)
        {
            if(dictionary == null)
                throw new ApplicationException("Коллекция Солюшенов не инициализирована");
            
            if (dictionary.ContainsKey(id))
            {
                //проверить что это тот же объект солюшена, с тем же адресом в памяти.
                //если нет - выдать исключение
                MSolution sol = dictionary[id];
                return sol;
            }
            else
                throw new ApplicationException("Объект Солюшена не найден в коллекции солюшенов");
        }

    }
}
