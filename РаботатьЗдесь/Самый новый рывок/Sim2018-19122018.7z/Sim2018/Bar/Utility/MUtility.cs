﻿using System;
using System.Collections.Generic;
using System.Text;
using Bar.DatabaseAdapters;
using System.Reflection;

namespace Bar.Utility
{
    internal static class MUtility
    {
            //TODO: тут тестировать извлечение атрибутов, когда весь солюшен будет компилироваться успешно.
            //написать код в тестовом проекте и пробовать его тестировать.

            //тут нужны 2 функции: список доступных типов БД (адаптеров БД)
            //и функция проверки, поддерживает ли Движок указанный тип БД.

        public static bool isSupportedDbType(MDatabaseType dbType)
        {
            throw new NotImplementedException();
            //TODO: Add code here - после отладки нижеследующего примера
        }

        /// <summary>
        /// NR-Получить список доступных типов БД
        /// </summary>
        /// <returns></returns>
        public static List<MDatabaseType> getAvailableDatabaseTypes()
        {

            List<MDatabaseType> result = new List<MDatabaseType>();
            try
            {
                //get current class type
                Type ty = typeof(BaseDbAdapter);
                Type at = typeof(MDatabaseTypeAttribute);
                //нельзя получить производные классы, только родительские.
                //поэтому берем всю сборку и в ней перебираем все классы, ищем классы с атрибутом
                //и его значение добавляем в список
                Assembly a = ty.Assembly;
                Type[] tar = a.GetTypes();//получаем всякие типы из текущей! сборки
                foreach (Type t in tar)
                {
                    Object[] attrs = t.GetCustomAttributes(at, false);
                    foreach (Object ob in attrs)
                    {
                        if (ob == null) continue;
                        //get attribute data
                        MDatabaseTypeAttribute mdta = (MDatabaseTypeAttribute)ob;
                        //add to list if Active value = true
                        if (mdta.Active == true)
                            result.Add(mdta.DatabaseType);
                    }
                }

            }
            catch (Exception ex)
            {
                ;
            }

            return result;
        }
    }
}
